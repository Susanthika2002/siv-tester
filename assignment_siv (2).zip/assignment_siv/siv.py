#!/usr/bin/env python3
from pathlib import Path
import datetime
import hashlib
from time import time
import os
import pandas as pd
import argparse


def mGetFileData(filePath,hashFunction):
    fileDataDict = {}
    stats = os.stat(filePath)
    fileDataDict['FullPath'] = os.path.abspath(filePath)
    fileDataDict['Size'] = stats.st_size
    path = Path(filePath)
    fileDataDict['Name of User'] = path.owner()
    fileDataDict['Name of Group'] = path.group()
    fileDataDict['Access Rights'] = oct(stats.st_mode)
    date_object = datetime.datetime.fromtimestamp(stats.st_mtime)
    fileDataDict['Last Modification Date'] = date_object.strftime('%Y-%m-%d-%H:%M')
    if os.path.isfile(filePath):
        with open(filePath,"rb") as f:
            bytes1 = f.read()
            if hashFunction=='md5':
                readable_hash = hashlib.md5(bytes1).hexdigest()
            else:
                readable_hash = hashlib.sha1(bytes1).hexdigest()
        fileDataDict['Computed message'] = readable_hash
        fileDataDict['Hash Function'] = hashFunction
    else:
        fileDataDict['Hash Function'] = ''
        fileDataDict['Computed message'] = ''
    return fileDataDict   

def mReportWarnings(verificationDf, newDf,reportFile=''):
    reqColumns=['FullPath','Size','Name of User','Name of Group','Access Rights','Last Modification Date','Computed message']
    warningCount = 0
    if len(verificationDf)<=0:
        warningCount+=1
        with open(reportPath,'a') as f:
            f.write(f"WARNING -- New File/Folder : '{newDf['FullPath']}' \n")
        return warningCount
    for col in reqColumns:
        if ((list(verificationDf[col])[0]!=newDf[col]) and newDf[col]!=''):
            warningCount+=1
            with open(reportPath,'a') as f:
                f.write(f'WARNING -- File/Folder Name : "{newDf["FullPath"]}"  Old {col} : {list(verificationDf[col])[0]}   New {col} : {newDf[col]} \n')
    return warningCount
    
    
def Initialisation(monitoredPath,verificationPath,reportPath,hashFunction):
    dirsParsedCount = 0
    filessParsedCount = 0
    details = {'FullPath':[],'Size':[],'Name of User':[],'Name of Group':[],'Access Rights':[],'Last Modification Date':[],'Hash Function':[],'Computed message':[]}
    startTime = time()
    finalData = []
    for (root, dirs, file) in os.walk(monitoredPath):
        dirsParsedCount+=1
        df = mGetFileData(root,hashFunction)
        finalData.append(df)
        for i in file:
            filessParsedCount+=1
            df = mGetFileData(root+'/'+i,hashFunction)
            finalData.append(df)
    finalData = pd.DataFrame(finalData)
    finalData.to_csv(verificationPath+'.csv')
    endTime = time()
    totalInitialisationTime = round(endTime - startTime,2)
    with open(reportPath,'w+') as f:
        f.write(f'Path to monitored directory : {os.path.abspath(monitoredPath)}\n')
        f.write(f'Path to verification file : {os.path.abspath(monitoredPath)}\n')
        f.write(f'Number of directories parsed : {dirsParsedCount}\n')
        f.write(f'Number of files parsed : {filessParsedCount}\n')
        f.write(f'Time to complete the initialization mode : {totalInitialisationTime} seconds\n')
        
def mVerification(monitoredPath,verificationPath,reportPath):
    verificationData = pd.read_csv(verificationPath+'.csv')
    verificationPaths = list(verificationData['FullPath'])
    dirsParsedCount = 0
    filessParsedCount = 0
    startTime = time()
    warningsCount = 0
    reqColumns=['FullPath','Size','Name of User','Name of Group','Access Rights','Last Modification Date','Computed message']
    finalData = []
    hashFunction = list(verificationData['Hash Function'])[0]
    for (root, dirs, file) in os.walk(monitoredPath):
        dirsParsedCount+=1
        df = mGetFileData(root,hashFunction)
        verificationDataTemp = verificationData[verificationData['FullPath']==df['FullPath']]
        if len(verificationDataTemp)>0:verificationPaths.remove(df['FullPath'])
        warningsCount+=mReportWarnings(verificationDataTemp, df)
        for i in file:
            filessParsedCount+=1
            df = mGetFileData(root+'/'+i,hashFunction)
            verificationDataTemp = verificationData[verificationData['FullPath']==df['FullPath']]
            if len(verificationDataTemp)>0:verificationPaths.remove(df['FullPath'])
            warningsCount+=mReportWarnings(verificationDataTemp, df)  
    endTime = time()
    totalInitialisationTime = round(endTime - startTime,2)
    for i in verificationPaths:
        warningsCount+=1
        with open(reportPath,'a') as f:
            f.write(f"WARNING -- Removed File/Folder:{i} \n")
    with open(reportPath,'a') as f:
        f.write('\n\n--------Report----------\n\n')
        f.write(f'Path to monitored directory : "{os.path.abspath(monitoredPath)}"\n')
        f.write(f'Path to verification file : "{os.path.abspath(monitoredPath)}"\n')
        f.write(f'Path to report file : "{os.path.abspath(monitoredPath)}"\n')
        f.write(f'Number of directories parsed : {dirsParsedCount}\n')
        f.write(f'Number of files parsed : {filessParsedCount}\n')
        f.write(f'Number of Warnings issued : {warningsCount}\n')
        f.write(f'Time to complete the initialization mode : {totalInitialisationTime} seconds\n')
        
if __name__=="__main__":
    parser = argparse.ArgumentParser()
    argParser = parser.add_mutually_exclusive_group()
    argParser.add_argument("-i",action='store_true',help='-i for Initialisation mode')
    argParser.add_argument("-v",action='store_true',help='-v for Verification mode')
#     parser.add_argument("-h",action='store_true')
    parser.add_argument("-D", type=str,help='-D for path to monitored directory')
    parser.add_argument("-V",type=str,help='-V for path to verification file')
    parser.add_argument("-R",type=str,help='-R for report file path')
    parser.add_argument("-H",type=str,help='-H for hash function if it is in Initialisation mode and available options are "md5" for MD5 and "sha1" for SHA1 message digest')
    args = parser.parse_args()
    if not args.i and not args.v:
        print("Choose atleast one mode from initialisation and verification modes")
    if args.i:
        monitoredPath = Path(args.D)
        verificationPath = Path(args.V)
        reportPath = Path(args.R)
        if not os.path.isdir(args.D):
            print("Please enter a valid monitored directory path..")
        elif args.H not in ['md5','sha1']:
            print("Choosen Hashing function is not supported.Please choose md5 or sha1") 
        elif monitoredPath in verificationPath.parents:
            print("Path to verification file should be outside monitored path")
        elif monitoredPath in reportPath.parents:
            print("Path to report file should be outside monitored path")
        else:
            print("Initialisation started..........")
            Initialisation(args.D,args.V,args.R,args.H)
            print("Initialisation completed...........")
    elif args.v:
        monitoredPath = Path(args.D)
        verificationPath = Path(args.V)
        reportPath = Path(args.R)
        if not os.path.isdir(args.D):
            print("Please enter a valid monitored directory path..")
        #if not os.path.isdir(args.V):
        #    print("Please enter a valid verification directory path..")
        elif monitoredPath in verificationPath.parents:
            print("Path to verification file should be outside monitored path")
        elif monitoredPath in reportPath.parents:
            print("Path to report file should be outside monitored path")
        else:
            print("Verification started........")
            mVerification(args.D,args.V,args.R)
            print("Verification completd.........")
